import React, { useState, useEffect } from 'react';

const Favoritos = () => {
  const [favoritos, setFavoritos] = useState([]);

  useEffect(() => {
    // Obtener la lista de favoritos desde el Local Storage al cargar el componente
    const favoritosGuardados = JSON.parse(localStorage.getItem('favoritos')) || [];
    setFavoritos(favoritosGuardados);
  }, [])

  const eliminarDeFavoritos = (id) => {
    const nuevosFavoritos = favoritos.filter((creacion) => creacion.id !== id);
    setFavoritos(nuevosFavoritos);

    // Actualizar el Local Storage con la nueva lista de favoritos
    localStorage.setItem('favoritos', JSON.stringify(nuevosFavoritos));
  }
  return (
    <div className="container">
      <h1>My Favourites</h1>
      <div className="row">
        {favoritos.map((creacion) => (
          <div key={creacion.id} className="col-md-4 mb-3">
            <div className="card">
              <img
                src={creacion.imagen}
                className="card-img-top"
                alt={creacion.titulo}
                style={{ height: '200px', objectFit: 'cover' }}
              />
              <div className="card-body">
                <h5 className="card-title">{creacion.titulo}</h5>
                <p className="card-text">{creacion.descripcion}</p>
                <p className="card-text">Fecha: {creacion.fecha}</p>
                <a href={creacion.url} className="btn btn-primary">
                  See more
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Favoritos;
