import React from "react";
import { Link } from "react-router-dom";
import { useForm } from "react-hook-form";

function Layout({ children }) {
  const { register, handleSubmit, reset } = useForm();

  const onSubmit = (data) => {
    console.log(data); 
    reset(); 
  };
  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <div className="container">
          <Link to="/" className="navbar-brand">
            CATALOGO
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav ms-auto">
              <li className="nav-item">
                <Link to="/" className="nav-link">
                  Home
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/Creaciones" className="nav-link">
                  Creations
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/Favoritos" className="nav-link">
                  Favourites
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/Info" className="nav-link">
                  Info
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>

      <main className="container mt-4">{children}</main>


      <footer className="footer mt-4 py-5" style={{ backgroundColor: "#f5f5f5" }}>
        <div className="container">
          <div className="row">
            <div className="col-md-6">
              <h5>Contact</h5>
              <form onSubmit={handleSubmit(onSubmit)}>
                <div className="mb-3">
                  <label htmlFor="name" className="form-label">
                    Name
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="name"
                    {...register("name", { required: true })}
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="email" className="form-label">
                    Email
                  </label>
                  <input
                    type="email"
                    className="form-control"
                    id="email"
                    {...register("email", { required: true })}
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="message" className="form-label">
                    Message
                  </label>
                  <textarea
                    className="form-control"
                    id="message"
                    rows="3"
                    {...register("message", { required: true })}
                  ></textarea>
                </div>
                <button type="submit" className="btn btn-primary">
                  Send
                </button>
              </form>
            </div>
            <div className="col-md-6">
            <h5>Social Networks</h5>
              <div className="d-flex align-items-center">
                <div className="me-3">
                  <img
                    src={"linkedin.png"}
                    className="card-img-top"
                    alt=""
                    style={{ height: '40px', width: '40px', objectFit: 'cover' }}
                  />
                </div>
                <div>
                  <a href="https://www.linkedin.com/in/julian-chareca-3695b2270?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base_contact_details%3Begz9u%2FI9SsC9c46a4FPS2Q%3D%3D">
                    <i className="fab fa-linkedin me-1"></i>  <i>. Julian Chareca</i>
                  </a>
                </div>
              </div>
              <div className="mt-3 d-flex align-items-center">
                <div className="me-3">
                  <img
                    src={"instagram.png"}
                    className="card-img-top"
                    alt=""
                    style={{ height: '60px', width: '60px', objectFit: 'cover' }}
                  />
                </div>
                <div>
                  <a href="https://www.instagram.com/cbum/?hl=es">
                    <i className="fab fa-instagram me-1"></i><i>@julianchareca</i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>


    </div>
  );
}

export default Layout;